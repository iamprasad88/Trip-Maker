package com.nyu.cs9033.eta.controllers;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.nyu.cs9033.eta.R;

public class EditTripFragment extends Fragment implements
		DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener

{

	Activity activity = null;
	public String tripName;
	public String tripDate;
	public String tripTime;
	public String tripLocation;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View root = inflater.inflate(R.layout.edit_trip_layout, null, true);

		EditText tname = (EditText) root.findViewById(R.id.editTripName);
		tname.setOnFocusChangeListener(new OnFocusChangeListener() {

			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus == false) {
					EditTripFragment.this.tripName = ((EditText) v).getText()
							.toString();
				}

			}
		});

		Button t = (Button) root.findViewById(R.id.setdate);
		t.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Calendar c = Calendar.getInstance();
				DatePickerDialog d = new DatePickerDialog(getActivity(),
						EditTripFragment.this, c.get(Calendar.YEAR), c
								.get(Calendar.MONTH), c
								.get(Calendar.DAY_OF_MONTH));
				d.show();
			}
		});

		return root;
	}

	public void updateTrip() {
		tripName = ((EditText) getView().findViewById(R.id.editTripName))
				.getText().toString();
		tripDate = ((TextView) getView().findViewById(R.id.editTripDate))
				.getText().toString();
		tripTime = ((TextView) getView().findViewById(R.id.editTripTime))
				.getText().toString();

		Log.v("Here2", tripDate);
	}

	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
		this.activity = activity;
	}

	@Override
	public void onPause() {
		super.onPause();

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

	}

	@Override
	public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
	}

	@Override
	public void onDateSet(DatePicker view, int year, int monthOfYear,
			int dayOfMonth) {
		Calendar c = Calendar.getInstance();
		TextView t = (TextView) getView().findViewById(R.id.editTripDate);
		String text = year + "/" + monthOfYear + "/" + dayOfMonth;
		t.setText(text);
		tripDate = text;
		TimePickerDialog tp = new TimePickerDialog(getActivity(),
				EditTripFragment.this, c.get(Calendar.HOUR),
				c.get(Calendar.MINUTE), true);
		tp.show();
	}

	@Override
	public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
		String text = hourOfDay + ":" + minute;
		TextView t = (TextView) getView().findViewById(R.id.editTripTime);
		t.setText(text);
		tripTime = text;
	}

	public void setTrip(String tripID) {

	}
}
