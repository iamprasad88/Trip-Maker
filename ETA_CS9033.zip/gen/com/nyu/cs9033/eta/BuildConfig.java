/** Automatically generated file. DO NOT MODIFY */
package com.nyu.cs9033.eta;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}